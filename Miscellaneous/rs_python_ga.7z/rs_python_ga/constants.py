#!python2
# Defaults
numRoutesToOutput = 1
populationSize = 100
elitismCount = 10
crossoverRate = 0.9
switchStnMutateRate = 0.001
routePosSwapMutateRate = 0.001
runDuration = 3
crisisMode = False
preferredBrand = ["all"]
start = None
end = None
