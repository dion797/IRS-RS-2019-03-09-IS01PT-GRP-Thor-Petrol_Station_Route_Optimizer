from numbers import Number
from openpyxl import load_workbook

wb = load_workbook("data.xlsx", data_only=True)

# Waypoints
sheet = wb["waypoints"]

start = None
end = None
waypoints = []

for i in range(2, sheet.max_row + 1):
  lat = sheet.cell(row = i, column = 3).value
  lon = sheet.cell(row = i, column = 4).value

  if (sheet.cell(row = i, column = 5).value == "true") or \
      (sheet.cell(row = i, column = 6).value == "true"):
    if sheet.cell(row = i, column = 5).value == "true":
      start = [lat, lon]
    if sheet.cell(row = i, column = 6).value == "true":
      end = [lat, lon]
  else:
    waypoints.append([lat,lon])
  

# Third, add stations
sheet = wb["stations"]

stations = []

for i in range(2, sheet.max_row + 1):
  lat = sheet.cell(row = i, column = 4).value
  lon = sheet.cell(row = i, column = 5).value
  
  stations.append([lat,lon])
