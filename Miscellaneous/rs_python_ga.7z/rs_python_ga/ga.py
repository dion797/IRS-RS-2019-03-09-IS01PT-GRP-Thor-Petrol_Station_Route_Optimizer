#!python2
import classes, constants

from numpy import array
from operator import itemgetter
from pandas import DataFrame
from random import random, sample
from time import time


population = []
waypointGenes = None
stationGenes = None


def makeRoute(station):
  route = []

  if constants.crisisMode:
    # Station must be first stop after start point
    route.append(station)
    route.append(sample(waypointGenes, len(waypointGenes)))
  else:
    # Everything can be randomised
    routeStops = waypointGenes[:]
    routeStops.append(station)
    route = sample(routeStops, len(routeStops))
  
  return route


def initPopulation():
  routeLen = len(waypointGenes) + 1

  # Pre-constructed solution:
  # If len(stations) <= constants.populationSize,
  #   every single Station will be represented by at least one gene
  # else,
  #   constants.populationSize random Stations will be selected for the initial population
  initStnSet = sample(stationGenes, min(len(stationGenes), constants.populationSize))
  for station in initStnSet:
    route = makeRoute(station)
    population.append(classes.Route(route))

  # If constants.populationSize > len(stations),
  # then population has not yet reached the required size in the previous step
  while len(population) < constants.populationSize:
    route = makeRoute(stationGenes[int(len(stationGenes) * random())])
    population.append(classes.Route(route))


def rankChromosomes():
  fitnessResults = {}
  for i in range(0, len(population)):
    fitnessResults[i] = population[i].routeFitness()

  return sorted(fitnessResults.items(), key = itemgetter(1), reverse = True)


def getElites(ranking):
  elites = []
  for i in range(constants.elitismCount):
    elites.append(population[ranking[i][0]])
    
  return elites


def selectParentPairs(ranking):
  parentPairs = []
  df = DataFrame(array(ranking), columns=["Index", "Fitness"])
  df["cum_sum"] = df.Fitness.cumsum()
  df["cum_perc"] = 100 * df.cum_sum / df.Fitness.sum()

  parentPair = None
  for i in range(0, len(population) - constants.elitismCount):
    if i % 2 == 0:
      # New parentPair
      parentPair = [None, None]
      
    pick = 100 * random()
    for j in range(0, len(ranking)):
      if pick <= df.iat[j, 3]:
        parentPair[i % 2] = ranking[j][0]
        break

    if i % 2 == 1:
      # Both parents selected
      parentPairs.append(parentPair)

  return parentPairs


def crossover(parent1, parent2):
  parent1Route = parent1.route
  parent2Route = parent2.route
  childRoute = [None] * len(parent1Route)
  # Boolean flag to ensure only 1 parent's Station is inherited
  stationInherited = False

  # Randomly splice half of parent 1's genes into child
  startPos = int((len(parent1Route) / 2) * random())
  for i in range(startPos, startPos + int(len(parent1Route) / 2) + 1):
    childRoute[i] = parent1Route[i]
    if isinstance(childRoute[i], classes.Station):
      stationInherited = True

  # Required Waypoints that aren't inherited from parent1 will be inherited from parent2,
  # in order of appearance within parent2's route array
  parent2SelectedGenes = []
  for i in range(len(parent2Route)):
    if (parent2Route[i] not in childRoute) and not (stationInherited and isinstance(parent2Route[i], classes.Station)):
      # If condition 1: This Location gene does not already exist in the child route
      # If condition 2: If child has already inherited a Station gene then this gene cannot be a Station
      parent2SelectedGenes.append(parent2Route[i])

  for i in range(len(childRoute)):
    if childRoute[i] == None:
      # Remove first gene in parent2SelectedGenes array and insert it into the next empty position in child array
      childRoute[i] = parent2SelectedGenes.pop(0)

  return classes.Route(childRoute)


def possibleMutate(child):
  childRoute = child.route
  # Chance to mutate to a different Station
  for i in range(len(childRoute)):
    if isinstance(childRoute[i], classes.Station) and (random() < constants.switchStnMutateRate):
      childRoute[i] = stationGenes[int(random() * len(stationGenes))]
      break

  # Chance for one gene to mutate and swap positions with another gene
  # Station must always be at route[0] if constants.crisisMode is True
  # int(True) = 1, int(False) = 0
  if random() < constants.routePosSwapMutateRate:
    firstPos = int(constants.crisisMode) + \
        int(random() * (len(childRoute) - int(constants.crisisMode)))
    secondPos = -1
    while secondPos < 0 or secondPos == firstPos:
      secondPos = int(constants.crisisMode) + \
          int(random() * (len(childRoute) - int(constants.crisisMode)))

    # Do the swap
    childRoute[firstPos], childRoute[secondPos] = childRoute[secondPos], childRoute[firstPos]

  
def breed(parentPairs):
  childrenPopulation = []

  # Crossover phase
  for pair in parentPairs:
    parent1 = population[pair[0]]
    parent2 = population[pair[1]]

    if random() < constants.crossoverRate:
      # Crossover occurs
      childrenPopulation.append(crossover(parent1, parent2))
      childrenPopulation.append(crossover(parent2, parent1))
    else:
      # Offspring are exact replicates of parents
      childrenPopulation.append(classes.Route(parent1.route[:]))
      childrenPopulation.append(classes.Route(parent2.route[:]))

  # Mutation phase
  for child in childrenPopulation:
    possibleMutate(child)

  return childrenPopulation


def nextGeneration():
  global population

  ranking = rankChromosomes()
  elites = getElites(ranking)
  parentPairs = selectParentPairs(ranking)
  children = breed(parentPairs)
  population = elites + children

def runGA(waypoints, stations):
  global waypointGenes, stationGenes
  waypointGenes = waypoints
  stationGenes = stations
  initPopulation()

  # Run GA within the configured time limit in seconds
  numGenerations = 0
  endTime = time() + constants.runDuration
  while time() < endTime:
    nextGeneration()
    numGenerations += 1

  print("GA complete: %d generations bred" % numGenerations)

  finalRanking = rankChromosomes()
  finalSolutions = []
  for i in range(constants.numRoutesToOutput):
    finalSolutions.append(population[i])

  return finalSolutions
