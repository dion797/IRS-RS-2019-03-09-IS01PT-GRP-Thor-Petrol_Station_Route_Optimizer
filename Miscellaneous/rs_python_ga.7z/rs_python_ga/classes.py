#!python2
import constants

from haversine import haversine

class Location(object):
  id = 0
  
  def __init__(self, lat, lon, name, address):
    self.id = Location.id
    Location.id += 1
    self.lat = lat
    self.lon = lon
    self.name = name
    self.address = address


class Waypoint(Location):
  # self.order: Placeholder for fixed order mode, presently unimplemented
  def __init__(self, lat, lon, name = "", address = "", order = 0):
    super(Waypoint, self).__init__(lat, lon, name, address)
    self.order = order

  def __repr__(self):
    return "Waypoint %d: %s (%f, %f)" % (self.id, self.name, self.lat, self.lon)


class Station(Location):
  def __init__(self, lat, lon, brand = "", name = "", address = ""):
    super(Station, self).__init__(lat, lon, name, address)
    self.brand = brand

  def __repr__(self):
    return "Station %d: %s %s (%f, %f)" % (self.id, self.brand, self.name, self.lat, self.lon)


# Routes as used in the code consists only of the variable portion
# i.e. The start and end Locations, which is always fixed, isn't part of the route variable
# but is still accounted for when scoring the Route
class Route:  
  # Static variables
  distMatrix = {}

  def __init__(self, route):
    self.route = route
    self.distance = 0.0
    self.cost = 0.0
    self.fitness = 0.0

  def __repr__(self):
    strOut = "Route sequence: Start Waypoint #%d" % constants.start.id
    for stop in self.route:
      if isinstance(stop, Waypoint):
        strOut += " > Waypoint "
      else:
        strOut += " > Station "
      strOut += "#%d" % stop.id
    strOut += " > End Waypoint #%d\n" % constants.end.id
    strOut += "Distance: %f Fitness Score: %f" % (self.distance, self.fitness)

    return strOut

  # Static method to calculate distance between two lat-lon coordinates
  @staticmethod
  def distBtwn(loc1, loc2):
    dist = 0
    pair = frozenset((loc1.id, loc2.id))

    if pair in Route.distMatrix:
      # Distance between this pair has been calculated before
      dist = Route.distMatrix[pair]
    else:
      # New pair, distance has not been calculated yet
      coords1 = (loc1.lat, loc1.lon)
      coords2 = (loc2.lat, loc2.lon)
      # Haversine function is used in navigation to estimate straight-line distances
      # between two coordinates, accounting for the spherical nature of the Earth
      dist = haversine(coords1, coords2)
      Route.distMatrix[pair] = dist
      
    return dist

  def routeDistance(self):
    # Total length of
    if self.distance == 0.0:
      pathDistance = Route.distBtwn(constants.start, self.route[0]) + Route.distBtwn(self.route[-1], constants.end)
      for i in range(len(self.route) - 1):
        pathDistance += Route.distBtwn(self.route[i], self.route[i + 1])
      self.distance = pathDistance
      
    return self.distance

  def routeCost(self):
    # To-do as possible enhancement
    # Accounts for refuelling cost at selected station
    if self.cost == 0.0:
      self.cost = 1.0
    
    return self.cost

  def routeFitness(self):
    if self.fitness == 0:
      self.fitness = 1 / float(self.routeDistance() * self.routeCost())
      
    return self.fitness




  
