from numbers import Number
from openpyxl import load_workbook

# Parses data.xlsx and converts the cells into JSON
# WARNING: Use this script for development purposes only!!!

message = '['

# Assumes data.xlsx is in the same directory as this script
# data_only reads the computed value of formulas in cells instead of the formula
wb = load_workbook("data.xlsx", data_only=True)

# First JSON object should be the configuration settings
sheet = wb["settings"]

obj = '{'
for i in range(1, sheet.max_row + 1):
  if i > 1:
    obj = obj + ','
  
  key = '"' + str(sheet.cell(row = i, column = 1).value) + '"'
  
  rawVal = sheet.cell(row = i, column = 2).value
  val = None
  if (isinstance(rawVal, Number)):
    val = str(rawVal)
  else:
    val = '"' + rawVal + '"'
  obj = obj + key + ':' + val
obj = obj + '}'

message = message + obj

# Second, add waypoints
sheet = wb["waypoints"]

for i in range(2, sheet.max_row + 1):
  name = '"name":"' + str(sheet.cell(row = i, column = 1).value) + '"'
  addr = sheet.cell(row = i, column = 2).value
  if addr == None:
    addr = '"address":""'
  else:
    addr = '"address":"' + str(addr) + '"'
  lat = '"lat":' + str(sheet.cell(row = i, column = 3).value)
  lon = '"lon":' + str(sheet.cell(row = i, column = 4).value)
  isWaypoint = '"is-waypoint":"true"'
  
  obj = '{' + name + ',' + addr + ',' + lat + ',' + lon + ',' + isWaypoint
  if sheet.cell(row = i, column = 5).value == "true":
    obj = obj + ',"is-start":"true"'
  if sheet.cell(row = i, column = 6).value == "true":
    obj = obj + ',"is-end":"true"'
  obj = obj + '}'

  message = message + ',' + obj

# Third, add stations
sheet = wb["stations"]

for i in range(2, sheet.max_row + 1):
  name = '"name":"' + str(sheet.cell(row = i, column = 1).value) + '"'
  addr = sheet.cell(row = i, column = 2).value
  if addr == None:
    addr = '"address":""'
  else:
    addr = '"address":"' + str(addr) + '"'
  brand = '"brand":"' + str(sheet.cell(row = i, column = 3).value) + '"'
  lat = '"lat":' + str(sheet.cell(row = i, column = 4).value)
  lon = '"lon":' + str(sheet.cell(row = i, column = 5).value)

  obj = '{' + name + ',' + addr + ',' + brand + ',' + lat + ',' + lon + '}'
  message = message + ',' + obj

message = message + ']'
