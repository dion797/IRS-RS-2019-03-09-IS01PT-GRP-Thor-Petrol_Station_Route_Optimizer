#!python2
import classes, constants

from ga import runGA
from json import loads, dumps
#from hardcodedData import *
# WARNING: Import for development use only (pre-integration), remove from submission build
#from data import message


# The gene pool
waypointGenes = []
stationGenes = []


def parseConfig(config):
  # Load configuration settings
  if "numRoutesToOutput" in config:
    constants.numRoutesToOutput = config["numRoutesToOutput"]

  if "populationSize" in config:
    constants.populationSize = config["populationSize"]

  if "elitismCount" in config:
    constants.elitismCount = config["elitismCount"]

  if "crossoverRate" in config:
    constants.crossoverRate = config["crossoverRate"]
    
  if "switchStnMutateRate" in config:
    constants.switchStnMutateRate = config["switchStnMutateRate"]

  if "routePosSwapMutateRate" in config:
    constants.routePosSwapMutateRate = config["routePosSwapMutateRate"]

  if "runDuration" in config:
    constants.runDuration = config["runDuration"]

  if "crisisMode" in config:
    constants.crisisMode = (config["crisisMode"].lower() == "true")

  if "preferredBrand" in config:
    constants.preferredBrand = config["preferredBrand"].lower().split(',')
    constants.preferredBrand = [i.strip() for i in constants.preferredBrand]


def parseLocation(location, isWaypoint):
  locationObj = None
  
  if isWaypoint:
    if isinstance(location, list):
      # lat-lon array
      locationObj = classes.Waypoint(location[0], location[1])
    else:
      # JSON object
      lat = location["lat"]
      lon = location["lon"]
      name = ""
      address = ""
      if "name" in location:
        name = location["name"].strip()
      if "address" in location:
        address = location["address"].strip()
      locationObj = classes.Waypoint(lat, lon, name, address)
  else:
    # isStation
    if isinstance(location, list):
      #lat-lon array
      locationObj = classes.Station(location[0], location[1])
    else:
      brand = location["brand"].strip().lower()
      if ("all" in constants.preferredBrand) or (brand in constants.preferredBrand):
        # Only add station if it matches brand filter
        lat = location["lat"]
        lon = location["lon"]
        name = ""
        address = ""
        if "name" in location:
          name = location["name"].strip()
        if "address" in location:
          address = location["address"].strip()
        locationObj = classes.Station(lat, lon, brand, name, address)

  return locationObj


def parseData(waypoints, stations, start, end):
  # Store start and end points separately from the gene pool
  # If they are passed in as separate parameters, assign them here
  if start != None:
    constants.start = parseLocation(start, isWaypoint = True)
  if end != None:
    constants.end = parseLocation(end, isWaypoint = True)

  for waypoint in waypoints:
    waypointObj = parseLocation(waypoint, isWaypoint = True)

    # If start and end were not already assigned, do it here
    # In this case, it is required that waypoints is an array of JSON objects
    # and not an array of lat-lon coord arrays
    if (constants.start != None) and (constants.end != None):
      waypointGenes.append(waypointObj)
    else:
      if (constants.start == None) and \
          ("is-start" in waypoint) and (waypoint["is-start"].lower() == "true"):
        constants.start = waypointObj
      if (constants.end == None) and \
          ("is-end" in waypoint) and (waypoint["is-end"].lower() == "true"):
        constants.end = waypointObj
        
  for station in stations:
    stationGenes.append(parseLocation(station, isWaypoint = False))


def parseJsonInput(jsonObj):
  config = jsonObj[0]
  parseConfig(config)

  waypoints = []
  stations = []
  start = None
  end = None
  
  for i in range(1, len(jsonObj)):
    location = jsonObj[i]
    if ("is-waypoint" in location) and (location["is-waypoint"].lower() == "true"):
      if ("is-start" in location) or ("is-end" in location):
        if ("is-start" in location) and (location["is-start"].lower() == "true"):
          start = location
        if ("is-end" in location) and (location["is-end"].lower() == "true"):
          end = location
      else:
        waypoints.append(location)
    else:
      stations.append(location)

  parseData(waypoints, stations, start, end)


def toLocationObject(location):
  # Build output JSON
  locObj = {}
  locObj["name"] = location.name
  locObj["lat"] = location.lat
  locObj["lon"] = location.lon
  locObj["address"] = location.address
  locObj["is-waypoint"] = isinstance(location, classes.Waypoint)
  
  return locObj


def main(jsonMsg = None, waypoints = None, stations = None, \
    start = None, end = None, config = None):
  # Offers 2 ways of calling function:
  # Method 1: Pass a JSON message containing all required config and input data
  # Method 2: Pass waypoints, stations, start, end and config as separate parameters
  #     config: Must always be a JSON object
  #     start, end: Can be either a JSON object or a lat-lon coord array
  #     waypoints: An array of JSON objects. If start and end are given separately, then it can
  #         also be an array of lat-lon coord arrays
  #     stations: If station data is passed in as JSON objects, then this is to be an array of
  #         JSON objects.
  #         If station data is passed in as lat-lon coord arrays, then this has to be either a
  #         dictionary (keys shall be the brand names), or an array of lat-lon coord arrays, in
  #         which case which there is no brand filtering applied

  # WARNING: Section for development use only (pre-integration), remove from submission build
  #if (jsonMsg == None) and (waypoints == None) and (stations == None):
    # Loads json message generated from Excel sample data
    #jsonMsg = message
  # End of section

  if jsonMsg != None:
    # Extract all data from JSON input
    parseJsonInput(loads(jsonMsg))
  else:
    # Data is passed in as separate parameters
    if config != None:
      parseConfig(config)

    parseData(waypoints, stations, start, end)

  # Run GA
  finalSolutions = runGA(waypointGenes, stationGenes)

  for i in finalSolutions:
    print(i)

  outputJsonObj = []
  for solution in finalSolutions:
    solnObj = {}
    solnObj["distance"] = solution.distance
    solnObj["cost"] = solution.cost # Monetary cost of solution. Currently unused, defaulted to 1
    solnObj["fitness"] = solution.fitness
    solnObj["route"] = []

    # Add start point
    locObj = toLocationObject(constants.start)
    locObj["is-start"] = True
    solnObj["route"].append(locObj)

    # Add middle points
    for location in solution.route:
      locObj = toLocationObject(location)
      if isinstance(location, classes.Waypoint):
        locObj["is-waypoint"] = True
      else:
        locObj["brand"] = location.brand
      solnObj["route"].append(locObj)

    # Add end point
    locObj = toLocationObject(constants.end)
    locObj["is-end"] = True
    solnObj["route"].append(locObj)

    outputJsonObj.append(solnObj)

  outputMessage = dumps(outputJsonObj)

  return outputMessage

#main(start = startLoc, end = endLoc, waypoints = waypointLocs, stations = stationLocs)




